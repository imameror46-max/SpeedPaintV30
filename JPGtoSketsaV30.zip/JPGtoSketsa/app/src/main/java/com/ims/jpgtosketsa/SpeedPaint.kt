package com.ims.jpgtosketsa

import android.graphics.*
import android.media.*
import java.io.File
import kotlin.math.*
import kotlin.random.Random

class PaintOptions(
    val style: Int = 0,       // 0 sketsa lalu warna, 1 langsung warna, 2 sketsa saja
    val direction: Int = 3,   // 0 kiri-kanan, 1 atas-bawah, 2 tengah keluar, 3 acak alami (beda tiap video)
    val paper: Int = 0,       // 0 putih, 1 krem, 2 papan tulis
    val ratio: Int = 0,       // 0 sesuai foto, 1 9:16, 2 1:1, 3 16:9
    val res: Int = 720,       // sisi terpanjang
    val handPct: Int = 55,    // lebar tangan, % dari lebar video
    val handSpeed: Float = 1f,
    val holdSec: Int = 1,
    val fps: Int = 30,
    val sens: Int = 0,        // 0 otomatis, 1 lebih sedikit garis, 2 lebih banyak
    val thick: Int = 0,       // 0 otomatis, 1 tipis, 2 sedang, 3 tebal
    val source: Int = 0,      // 0 otomatis, 1 tepi (foto), 2 area gelap (gambar hitam-putih)
    val ink: Int = 0,         // 0 otomatis, 1 biru tua, 2 cokelat sepia, 3 abu pensil, 4 warna asli
    val transparentSrc: Boolean = false   // sumber = sketsa PNG transparan (hanya garis)
)

object SpeedPaint {
    private val PAPER = intArrayOf(0xFFFFFFFF.toInt(), 0xFFF5ECD7.toInt(), 0xFF2B3A33.toInt(), 0xFFF3EFE0.toInt())
    private val INK = intArrayOf(0xFF222222.toInt(), 0xFF3A2E1E.toInt(), 0xFFF2F2F2.toInt(), 0xFF222222.toInt())
    private val INK2 = intArrayOf(0xFF888888.toInt(), 0xFF8C7F68.toInt(), 0xFF9AA39E.toInt(), 0xFF888888.toInt())

    fun render(
        src: Bitmap, seconds: Int, out: File, o: PaintOptions, hand: Bitmap?,
        cancelled: () -> Boolean, onProgress: (Int) -> Unit
    ) {
        val fps = o.fps
        val total = seconds * fps
        val r = o.res
        val (w0, h0) = when (o.ratio) {
            1 -> Pair(r * 9 / 16, r)
            2 -> Pair(r, r)
            3 -> Pair(r, r * 9 / 16)
            else -> {
                val sc = r.toFloat() / max(src.width, src.height)
                Pair((src.width * sc).toInt(), (src.height * sc).toInt())
            }
        }
        val w = w0 and 1.inv()
        val h = h0 and 1.inv()
        val n = w * h

        // Kanvas kertas + foto di tengah
        val canvasBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val bc = Canvas(canvasBmp)
        drawPaper(bc, w, h, o.paper)
        val paperImg = IntArray(n).also { canvasBmp.getPixels(it, 0, w, 0, 0, w, h) }
        val s = min(w.toFloat() / src.width, h.toFloat() / src.height)
        val dw = src.width * s
        val dh = src.height * s
        val dst = RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2)
        val pPhoto = Paint(Paint.FILTER_BITMAP_FLAG)
        // Foto dilebur ke kertas (multiply): bagian terang foto menampilkan kertas beserta garisnya
        // Catatan: MULTIPLY Android = modulate (hasil = src*dst termasuk alpha), sehingga piksel transparan menjadi HITAM transparan.
        // Karena itu untuk sumber transparan perkalian dengan kertas dilakukan manual di bawah.
        if (o.paper != 2 && !o.transparentSrc) pPhoto.xfermode = PorterDuffXfermode(PorterDuff.Mode.MULTIPLY)
        bc.drawBitmap(src, null, dst, pPhoto)
        val color = IntArray(n).also { canvasBmp.getPixels(it, 0, w, 0, 0, w, h) }
        canvasBmp.recycle()
        // Versi polos (foto di atas putih) untuk deteksi garis, agar garis kertas tidak ikut terdeteksi
        val pb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val pc = Canvas(pb)
        pc.drawColor(Color.WHITE)
        pc.drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        val plain = IntArray(n).also { pb.getPixels(it, 0, w, 0, 0, w, h) }
        pb.recycle()
        val transp = o.transparentSrc
        if (transp && o.paper != 2) {
            // Sketsa transparan: warna = sketsa (di atas putih) dikali kertas, selalu opak. Kertas krem/bergaris tetap tampak.
            for (i in 0 until n) {
                val pp = paperImg[i]
                val sc = plain[i]
                color[i] = Color.rgb(
                    Color.red(pp) * Color.red(sc) / 255,
                    Color.green(pp) * Color.green(sc) / 255,
                    Color.blue(pp) * Color.blue(sc) / 255
                )
            }
        }
        val alphaArr = if (transp) {
            if (o.paper == 2) {
                val ab = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                Canvas(ab).drawBitmap(src, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
                val arr = IntArray(n)
                ab.getPixels(arr, 0, w, 0, 0, w, h)
                ab.recycle()
                IntArray(n) { arr[it] ushr 24 }
            } else {
                // Kekuatan tinta = seberapa gelap piksel dibanding kertas. Alpha tidak dipakai karena pada
                // mode "isi objek opak" seluruh siluet beralpha penuh (menyebabkan pola kotak saat digambar).
                IntArray(n) { (255 - grayOf(plain[it])).coerceIn(0, 255) }
            }
        } else IntArray(0)

        // Penelusuran garis: urutan piksel mengikuti goresan
        val useSeq = o.style != 1
        val rx0 = ((w - dw) / 2f).toInt().coerceIn(0, w - 1)
        val ry0 = ((h - dh) / 2f).toInt().coerceIn(0, h - 1)
        val rx1 = ((w + dw) / 2f).toInt().coerceIn(rx0 + 1, w)
        val ry1 = ((h + dh) / 2f).toInt().coerceIn(ry0 + 1, h)
        val dark = useSeq && !transp && when (o.source) {
            1 -> false
            2 -> true
            else -> isLineArt(plain, w, rx0, ry0, rx1, ry1)
        }
        val mask = when {
            !useSeq -> BooleanArray(0)
            transp -> { val tt0 = if (o.paper == 2) 30 else 24; BooleanArray(n) { alphaArr[it] > tt0 } }
            dark -> darkMask(plain, w, h, rx0, ry0, rx1, ry1, o.sens)
            else -> edgeMask(plain, w, h, o.sens)
        }
        if (useSeq && !dark && !transp) clipMask(mask, w, h, rx0, ry0, rx1, ry1, 3)
        var inkCount = 0
        for (m in mask) if (m) inkCount++
        val frac = inkCount.toFloat() / n
        val br = if (transp) 0 else when (o.thick) {
            1 -> 0
            2 -> 1
            3 -> 2
            else -> {
                if (dark) 0 else {
                    var r0 = (max(w, h) / 540f).roundToInt()
                    if (frac > 0.10f) r0 -= 1
                    if (frac < 0.03f) r0 += 1
                    r0.coerceIn(0, 2)
                }
            }
        }
        // Urutan menggambar. Arah 3 = acak alami: gambar per BAGIAN (mis. kaki, kepala, lengan, badan) dengan urutan
        // acak, beda tiap video. Arah 0..2 = sapuan kiri-kanan / atas-bawah / tengah keluar.
        val rnd = Random(System.nanoTime())
        var dirMode = o.direction
        if (dirMode == 3) dirMode = 6
        var inkTotal = 0
        if (mask.size == n) for (mk in mask) if (mk) inkTotal++
        if (dirMode == 6 && inkTotal < 200) dirMode = 4          // garis terlalu sedikit: sapuan bersudut acak
        val regional = dirMode == 6
        val sweepAng = when (dirMode) {
            0 -> 0f
            1 -> (PI / 2).toFloat()
            4 -> rnd.nextFloat() * 2f * PI.toFloat()
            else -> 0f
        }
        val radial = dirMode == 2 || dirMode == 5
        val cx = w / 2f
        val cy = h / 2f
        val maxd = max(max(hypot(cx, cy), hypot(w - cx, cy)), max(hypot(cx, h - cy), hypot(w - cx, h - cy)))
        val ca = cos(sweepAng)
        val sa = sin(sweepAng)
        val pMin = min(min(0f, w * ca), min(h * sa, w * ca + h * sa))
        val pMax = max(max(0f, w * ca), max(h * sa, w * ca + h * sa))
        val pSpan = max(1f, pMax - pMin)
        val buckets = 2000
        var cell: IntArray? = null
        var cellOrder: IntArray? = null
        val key: IntArray
        if (regional) {
            // Bagian = sel Voronoi dari titik-titik tinta yang saling berjauhan (kepala, kaki, tangan, badan, ...)
            val kCells = 5 + rnd.nextInt(4)
            val cap = 3000
            val sxs = IntArray(cap + 1)
            val sys = IntArray(cap + 1)
            var cntS = 0
            val stride = max(1, inkTotal / cap)
            var seen = 0
            for (i in 0 until n) if (mask[i]) {
                if (seen % stride == 0 && cntS < cap) { sxs[cntS] = i % w; sys[cntS] = i / w; cntS++ }
                seen++
            }
            val seedX = FloatArray(kCells)
            val seedY = FloatArray(kCells)
            val md = FloatArray(cntS) { Float.MAX_VALUE }
            var curI = rnd.nextInt(cntS)
            for (k in 0 until kCells) {
                seedX[k] = sxs[curI].toFloat(); seedY[k] = sys[curI].toFloat()
                var best = -1f
                var bi = 0
                for (j in 0 until cntS) {
                    val dx = sxs[j] - seedX[k]
                    val dy = sys[j] - seedY[k]
                    val d = dx * dx + dy * dy
                    if (d < md[j]) md[j] = d
                    if (md[j] > best) { best = md[j]; bi = j }
                }
                curI = bi
            }
            val cl = IntArray(n)
            for (i in 0 until n) {
                val x = i % w
                val y = i / w
                var bd = Float.MAX_VALUE
                var bk = 0
                for (k in 0 until kCells) {
                    val dx = x - seedX[k]
                    val dy = y - seedY[k]
                    val d = dx * dx + dy * dy
                    if (d < bd) { bd = d; bk = k }
                }
                cl[i] = bk
            }
            val perm = (0 until kCells).shuffled(rnd)
            val rankOf = IntArray(kCells)
            for (r in 0 until kCells) rankOf[perm[r]] = r
            val ang = FloatArray(kCells) { rnd.nextFloat() * 2f * PI.toFloat() }
            val pmn = FloatArray(kCells) { Float.MAX_VALUE }
            val pmx = FloatArray(kCells) { -Float.MAX_VALUE }
            for (i in 0 until n) {
                val k = cl[i]
                val pr = (i % w) * cos(ang[k]) + (i / w) * sin(ang[k])
                if (pr < pmn[k]) pmn[k] = pr
                if (pr > pmx[k]) pmx[k] = pr
            }
            key = IntArray(n) { i ->
                val k = cl[i]
                val pr = (i % w) * cos(ang[k]) + (i / w) * sin(ang[k])
                val b = ((pr - pmn[k]) / max(1f, pmx[k] - pmn[k])).coerceIn(0f, 1f) * 0.94f + rnd.nextFloat() * 0.06f
                ((rankOf[k] + b.coerceIn(0f, 1f)) / kCells * (buckets - 1)).toInt().coerceIn(0, buckets - 1)
            }
            cell = cl
            cellOrder = perm.toIntArray()
        } else {
            key = IntArray(n) { i ->
                val x = i % w
                val y = i / w
                val b = if (radial) {
                    val d = hypot(x - cx, y - cy) / maxd
                    if (dirMode == 5) 1f - d else d
                } else (x * ca + y * sa - pMin) / pSpan
                ((b.coerceIn(0f, 1f) * 0.94f + rnd.nextFloat() * 0.06f) * (buckets - 1)).toInt()
            }
        }
        val cnt = IntArray(buckets + 1)
        for (k in key) cnt[k + 1]++
        for (i in 0 until buckets) cnt[i + 1] += cnt[i]
        val order = IntArray(n)
        for (i in 0 until n) order[cnt[key[i]]++] = i

        val flowGray = if (useSeq) IntArray(n) { grayOf(if (transp) color[it] else plain[it]) } else IntArray(0)
        val seq = if (useSeq) traceNatural(mask, flowGray, w, h, order, rnd, cell, cellOrder) else IntArray(0)
        val inkFixed = when {
            o.paper == 2 && o.ink in 1..3 -> INK[2]
            o.ink == 1 -> 0xFF1F2A8C.toInt()
            o.ink == 2 -> 0xFF5A3A22.toInt()
            o.ink == 3 -> 0xFF4A4A4A.toInt()
            else -> INK[o.paper]
        }
        fun inkAt(p: Int): Int = when {
            transp && (o.ink == 0 || o.ink == 4) -> color[p]
            transp -> blend(paperImg[p], inkFixed, alphaArr[p])
            o.ink == 4 -> plain[p]
            else -> inkFixed
        }
        val sketchFinal = paperImg.copyOf()
        for (p in seq) stamp(sketchFinal, p, w, h, br, inkAt(p))
        val fillMode = o.style == 3
        val trace = if (fillMode) growFill(seq, w, h, order) else seq

        val cur = paperImg.copyOf()
        val frame = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val hs = hand?.let {
            val hw = max(8, (w * o.handPct / 100f).toInt())
            Bitmap.createScaledBitmap(it, hw, max(1, it.height * hw / it.width), true)
        }

        // Encoder
        val fmt = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, (if (max(w, h) >= 1000) 8_000_000 else 4_000_000) * (if (fps > 30) 3 else 2) / 2)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType("video/avc")
        codec.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = codec.createInputSurface()
        codec.start()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var outCount = 0L
        val info = MediaCodec.BufferInfo()

        fun drain(eos: Boolean) {
            if (eos) codec.signalEndOfInputStream()
            while (true) {
                val i = codec.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
                when {
                    i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!eos) return
                    i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        track = muxer.addTrack(codec.outputFormat); muxer.start()
                    }
                    i >= 0 -> {
                        val buf = codec.getOutputBuffer(i)!!
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0) {
                            info.presentationTimeUs = outCount++ * 1_000_000L / fps
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            muxer.writeSampleData(track, buf, info)
                        }
                        codec.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }

        val hold = min(o.holdSec * fps, total / 2)
        val s2 = max(2, total - hold)                 // frame terakhir menggambar
        val half = if (o.style == 0) max(1, s2 * 65 / 100) else s2   // akhir fase garis
        val finalImg = if (o.style == 2) sketchFinal else color
        var rev = 0
        var hx = 0f
        var hy = 0f
        var started = false

        try {
            for (f in 0 until total) {
                if (cancelled()) break
                var drawing = true
                val tt = f * 30f / fps
                if (o.style == 0 && f == half) rev = 0
                val from = rev
                var tx = hx
                var ty = hy
                var fresh = false
                if (f < s2) {
                    val inFirst = f < half
                    val start = if (inFirst) 0 else half
                    val len = if (inFirst) half else s2 - half
                    if (inFirst && useSeq) {
                        val t = (trace.size.toLong() * (f - start + 1) / len).toInt()
                        for (j in rev until t) {
                            val p = trace[j]
                            if (fillMode) cur[p] = color[p] else stamp(cur, p, w, h, br, inkAt(p))
                        }
                        rev = t
                        if (rev > from) { val idx = trace[rev - 1]; tx = (idx % w).toFloat(); ty = (idx / w).toFloat(); fresh = true }
                    } else {
                        val t = (n.toLong() * (f - start + 1) / len).toInt()
                        for (j in rev until t) cur[order[j]] = color[order[j]]
                        rev = t
                        if (rev > from) {
                            val k = min(rev - from, 50)
                            val step = max(1, (rev - from) / k)
                            var sx = 0L
                            var sy = 0L
                            for (q in 0 until k) {
                                val idx = order[rev - 1 - q * step]
                                sx += idx % w
                                sy += idx / w
                            }
                            var px = sx.toFloat() / k
                            var py = sy.toFloat() / k
                            val wob = sin(tt * 0.9f * o.handSpeed)
                            if (regional) {
                                // Per bagian: tangan ada di rata-rata piksel terbaru, sedikit bergoyang
                                val wb = 0.03f * min(w, h)
                                px += wb * cos(tt * 1.7f * o.handSpeed)
                                py += wb * sin(tt * 2.3f * o.handSpeed)
                            } else if (radial) {
                                val frac = rev.toFloat() / n
                                val rad = (if (dirMode == 5) 1f - frac else frac) * maxd * 0.8f
                                val a2 = tt * 0.35f * o.handSpeed
                                px = cx + rad * cos(a2)
                                py = cy + rad * sin(a2)
                            } else {
                                // Depan sapuan = rata-rata piksel terbaru; tangan mengayun tegak lurus arah sapuan
                                val aa = px * ca + py * sa
                                val ext = abs(w * sa) + abs(h * ca)
                                val bb = (-w * 0.5f * sa + h * 0.5f * ca) + 0.4f * ext * wob
                                px = aa * ca - bb * sa
                                py = aa * sa + bb * ca
                            }
                            tx = px; ty = py; fresh = true
                        }
                    }
                } else {
                    drawing = false
                    System.arraycopy(finalImg, 0, cur, 0, n)
                }
                if (fresh) {
                    if (!started) { hx = tx; hy = ty; started = true }
                    else { val k2 = 0.45f * o.handSpeed.coerceAtMost(2f) * 30f / fps; hx += (tx - hx) * k2.coerceAtMost(1f); hy += (ty - hy) * k2.coerceAtMost(1f) }
                }
                frame.setPixels(cur, 0, w, 0, 0, w, h)
                val c = surface.lockCanvas(null)
                c.drawBitmap(frame, 0f, 0f, null)
                if (hs != null && drawing && started) {
                    c.drawBitmap(hs, hx.coerceIn(0f, w.toFloat()), hy - 0.96f * hs.height, null)
                }
                surface.unlockCanvasAndPost(c)
                drain(false)
                onProgress(f * 100 / total)
            }
            drain(true)
        } finally {
            codec.stop(); codec.release()
            if (track >= 0) muxer.stop()
            muxer.release(); surface.release()
        }
    }

    private fun grayOf(c: Int) = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10

    /** Gambar hampir tanpa warna (hitam-putih/abu-abu) dianggap line-art. */
    private fun isLineArt(px: IntArray, w: Int, x0: Int, y0: Int, x1: Int, y1: Int): Boolean {
        var gray = 0L
        var all = 0L
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = px[y * w + x]
                val mx = max(Color.red(c), max(Color.green(c), Color.blue(c)))
                val mn = min(Color.red(c), min(Color.green(c), Color.blue(c)))
                if (mx - mn < 24) gray++
                all++
                x += 3
            }
            y += 3
        }
        return all > 0 && gray.toDouble() / all > 0.96
    }

    /** Area gelap sebagai tinta (Otsu pada kecerahan), termasuk bagian hitam penuh. */
    private fun darkMask(px: IntArray, w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, sens: Int): BooleanArray {
        val hist = IntArray(256)
        for (y in y0 until y1) for (x in x0 until x1) hist[grayOf(px[y * w + x])]++
        val tot = ((x1 - x0).toLong() * (y1 - y0).toLong())
        var sumAll = 0L
        for (t in 0 until 256) sumAll += t.toLong() * hist[t]
        var wB = 0L
        var sumB = 0L
        var best = -1.0
        var thr = 100
        for (t in 0 until 256) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = tot - wB
            if (wF <= 0L) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        thr = thr.coerceIn(40, 128)
        if (sens == 1) thr = (thr * 0.75f).toInt()
        if (sens == 2) thr = min(160, (thr * 1.25f).toInt())
        val mask = BooleanArray(w * h)
        for (y in y0 until y1) for (x in x0 until x1) mask[y * w + x] = grayOf(px[y * w + x]) < thr
        return mask
    }

    /** Peta garis tepi dengan ambang otomatis (Otsu pada gradien), disesuaikan agar jumlah garis wajar. */
    private fun edgeMask(px: IntArray, w: Int, h: Int, sens: Int): BooleanArray {
        val g0 = IntArray(w * h) { (Color.red(px[it]) * 3 + Color.green(px[it]) * 6 + Color.blue(px[it])) / 10 }
        val g = IntArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            g[i] = (g0[i - w - 1] + g0[i - w] + g0[i - w + 1] + g0[i - 1] + g0[i] + g0[i + 1] + g0[i + w - 1] + g0[i + w] + g0[i + w + 1]) / 9
        }
        val mag = ShortArray(w * h)
        val hist = IntArray(1024)
        for (y in 2 until h - 2) for (x in 2 until w - 2) {
            val i = y * w + x
            val gx = -g[i - w - 1] - 2 * g[i - 1] - g[i + w - 1] + g[i - w + 1] + 2 * g[i + 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            val m = min(1023, abs(gx) + abs(gy))
            mag[i] = m.toShort()
            hist[m]++
        }
        val tot = ((w - 4).toLong() * (h - 4).toLong())
        var sumAll = 0L
        for (t in 0 until 1024) sumAll += t.toLong() * hist[t]
        var wB = 0L
        var sumB = 0L
        var best = -1.0
        var thr = 80
        for (t in 0 until 1024) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = tot - wB
            if (wF <= 0L) break
            sumB += t.toLong() * hist[t]
            val mB = sumB.toDouble() / wB
            val mF = (sumAll - sumB).toDouble() / wF
            val v = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (v > best) { best = v; thr = t }
        }
        fun fracAbove(t: Int): Double {
            var c = 0L
            for (i in t + 1 until 1024) c += hist[i]
            return c.toDouble() / tot
        }
        thr = thr.coerceIn(40, 250)
        while (thr < 600 && fracAbove(thr) > 0.12) thr += 5
        while (thr > 25 && fracAbove(thr) < 0.015) thr -= 5
        if (sens == 1) thr = (thr * 1.6f).toInt()
        if (sens == 2) thr = max(20, (thr * 0.6f).toInt())
        val mask = BooleanArray(w * h)
        for (i in 0 until w * h) mask[i] = mag[i] > thr
        return mask
    }

    /** Kertas polos, atau kertas buku bergaris dengan lubang di kiri. */
    private fun drawPaper(c: Canvas, w: Int, h: Int, paper: Int) {
        c.drawColor(PAPER[paper])
        if (paper != 3) return
        val sp = max(16f, h / 32f)
        val line = Paint().apply { color = 0xFFB9BFCC.toInt(); strokeWidth = max(1f, w / 600f) }
        var y = sp * 3.2f
        while (y < h - sp * 0.5f) {
            c.drawLine(w * 0.07f, y, w * 0.97f, y, line)
            y += sp
        }
        val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE9EAEE.toInt() }
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = 0xFFC9CCD4.toInt(); strokeWidth = max(1f, w / 500f)
        }
        var hy = sp * 3.2f
        while (hy < h - sp) {
            c.drawCircle(w * 0.028f, hy, w * 0.017f, hole)
            c.drawCircle(w * 0.028f, hy, w * 0.017f, ring)
            hy += sp * 1.7f
        }
    }

    private fun clipMask(m: BooleanArray, w: Int, h: Int, x0: Int, y0: Int, x1: Int, y1: Int, pad: Int) {
        for (y in 0 until h) {
            val o = y * w
            val inY = y >= y0 + pad && y < y1 - pad
            for (x in 0 until w) if (!(inY && x >= x0 + pad && x < x1 - pad)) m[o + x] = false
        }
    }

    /** Urutan isi: goresan dulu, lalu warna merambat keluar dari garis (BFS). */
    private fun growFill(seq: IntArray, w: Int, h: Int, fallback: IntArray): IntArray {
        if (seq.isEmpty()) return fallback
        val n = w * h
        val q = IntArray(n)
        val seen = BooleanArray(n)
        var tail = 0
        for (p in seq) { q[tail++] = p; seen[p] = true }
        var head = 0
        while (head < tail) {
            val p = q[head++]
            val x = p % w
            if (x > 0 && !seen[p - 1]) { seen[p - 1] = true; q[tail++] = p - 1 }
            if (x < w - 1 && !seen[p + 1]) { seen[p + 1] = true; q[tail++] = p + 1 }
            if (p >= w && !seen[p - w]) { seen[p - w] = true; q[tail++] = p - w }
            if (p < n - w && !seen[p + w]) { seen[p + w] = true; q[tail++] = p + w }
        }
        return if (tail == n) q else fallback
    }

    private fun blend(bg: Int, fg: Int, a: Int): Int {
        val t = a / 255f
        val r = (Color.red(bg) * (1 - t) + Color.red(fg) * t).toInt()
        val g = (Color.green(bg) * (1 - t) + Color.green(fg) * t).toInt()
        val b = (Color.blue(bg) * (1 - t) + Color.blue(fg) * t).toInt()
        return Color.rgb(r, g, b)
    }

    private fun stamp(a: IntArray, p: Int, w: Int, h: Int, r: Int, c: Int) {
        val x = p % w
        val y = p / w
        for (dy in 0..r) {
            val yy = y + dy
            if (yy >= h) break
            for (dx in 0..r) {
                val xx = x + dx
                if (xx >= w) break
                a[yy * w + xx] = c
            }
        }
    }

    /** Blur kotak (2 lintasan) pada array float, tepi di-clamp. */
    private fun blurF(a: FloatArray, w: Int, h: Int, r: Int) {
        val t = FloatArray(max(w, h))
        val k = (2 * r + 1).toFloat()
        repeat(2) {
            for (y in 0 until h) {
                val o = y * w
                var sum = 0f
                for (i in -r..r) sum += a[o + i.coerceIn(0, w - 1)]
                for (x in 0 until w) {
                    t[x] = sum / k
                    sum += a[o + min(x + r + 1, w - 1)] - a[o + max(x - r, 0)]
                }
                System.arraycopy(t, 0, a, o, w)
            }
            for (x in 0 until w) {
                var sum = 0f
                for (i in -r..r) sum += a[i.coerceIn(0, h - 1) * w + x]
                for (y in 0 until h) {
                    t[y] = sum / k
                    sum += a[min(y + r + 1, h - 1) * w + x] - a[max(y - r, 0) * w + x]
                }
                for (y in 0 until h) a[y * w + x] = t[y]
            }
        }
    }

    /**
     * Urutan gambar yang alami. Garis tipis (kontur) ditelusuri sebagai satu goresan; area padat (arsiran,
     * blok gelap) digambar dengan goresan-goresan pendek searah alur sketsa seperti arsir tangan, bukan
     * disapu per piksel yang membentuk pola kotak. Urutan titik awal mengikuti arah sapuan (order).
     */
    private fun traceNatural(
        mask: BooleanArray, gray: IntArray, w: Int, h: Int, order: IntArray, rnd: Random,
        cell: IntArray?, cellOrder: IntArray?
    ): IntArray {
        val n = w * h
        // Piksel inti = seluruh 8 tetangganya tinta; area padat = inti + tepinya
        val core = BooleanArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            if (mask[i] && mask[i - 1] && mask[i + 1] && mask[i - w] && mask[i + w] &&
                mask[i - w - 1] && mask[i - w + 1] && mask[i + w - 1] && mask[i + w + 1]) core[i] = true
        }
        val dense = BooleanArray(n)
        var denseCount = 0
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            if (!mask[i]) continue
            if (core[i] || core[i - 1] || core[i + 1] || core[i - w] || core[i + w] ||
                core[i - w - 1] || core[i - w + 1] || core[i + w - 1] || core[i + w + 1]) { dense[i] = true; denseCount++ }
        }
        val thin = BooleanArray(n) { mask[it] && !dense[it] }
        // Mode per bagian: kontur tipis juga digambar bagian demi bagian (sesuai urutan acak)
        val parts: Array<IntArray>
        val rankOf: IntArray?
        if (cell != null && cellOrder != null && cellOrder.isNotEmpty()) {
            parts = Array(cellOrder.size) { r ->
                val c = cellOrder[r]
                traceStrokes(BooleanArray(n) { thin[it] && cell[it] == c }, w, h, order, 4)
            }
            val ro = IntArray(cellOrder.size)
            for (r in cellOrder.indices) ro[cellOrder[r]] = r
            rankOf = ro
        } else {
            parts = arrayOf(traceStrokes(thin, w, h, order))
            rankOf = null
        }
        if (denseCount == 0) {
            var tot = 0
            for (pt in parts) tot += pt.size
            val r0 = IntArray(tot)
            var ps = 0
            for (pt in parts) { System.arraycopy(pt, 0, r0, ps, pt.size); ps += pt.size }
            return r0
        }

        // Medan arah goresan dari tensor struktur sketsa; area datar condong ke sudut acak (beda tiap video)
        val jxx = FloatArray(n)
        val jyy = FloatArray(n)
        val jxy = FloatArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = (gray[i + 1] - gray[i - 1]).toFloat()
            val gy = (gray[i + w] - gray[i - w]).toFloat()
            jxx[i] = gx * gx; jyy[i] = gy * gy; jxy[i] = gx * gy
        }
        val br = max(3, max(w, h) / 150)
        blurF(jxx, w, h, br); blurF(jyy, w, h, br); blurF(jxy, w, h, br)
        val ang0 = rnd.nextFloat() * PI.toFloat()
        val c0 = cos(2f * ang0)
        val s0 = sin(2f * ang0)
        val fx = FloatArray(n)
        val fy = FloatArray(n)
        for (i in 0 until n) {
            if (!dense[i]) continue
            val a = jxx[i] - jyy[i]
            val b = 2f * jxy[i]
            val bias = 0.25f * (jxx[i] + jyy[i]) + 150f
            val phi = 0.5f * atan2(-b + bias * s0, -a + bias * c0)
            fx[i] = cos(phi); fy[i] = sin(phi)
        }

        val visited = BooleanArray(n)
        val seqD = IntArray(denseCount)
        var sl = 0
        val half = (max(w, h) / 55).coerceIn(8, 28)
        val bufF = IntArray(half)
        val bufB = IntArray(half)
        fun walk(sx: Int, sy: Int, sign: Float, buf: IntArray): Int {
            var x = sx.toFloat()
            var y = sy.toFloat()
            val s0i = sy * w + sx
            var dx = fx[s0i] * sign
            var dy = fy[s0i] * sign
            var cnt = 0
            var vrun = 0
            var last = s0i
            var guard = 0
            while (cnt < half && guard < half * 3) {
                guard++
                x += dx; y += dy
                val ix = (x + 0.5f).toInt()
                val iy = (y + 0.5f).toInt()
                if (ix <= 0 || iy <= 0 || ix >= w - 1 || iy >= h - 1) break
                val p = iy * w + ix
                if (!dense[p]) break
                var nx = fx[p]
                var ny = fy[p]
                if (nx * dx + ny * dy < 0f) { nx = -nx; ny = -ny }
                dx = 0.75f * dx + 0.25f * nx
                dy = 0.75f * dy + 0.25f * ny
                val m = hypot(dx, dy)
                if (m < 1e-3f) break
                dx /= m; dy /= m
                if (p == last) continue
                last = p
                if (visited[p]) { vrun++; if (vrun >= 3) break; continue }
                vrun = 0
                visited[p] = true
                buf[cnt++] = p
            }
            return cnt
        }
        val segEnd = IntArray(parts.size)
        var rr = 0
        for (start in order) {
            if (!dense[start] || visited[start]) continue
            if (rankOf != null && cell != null) {
                val rk = rankOf[cell[start]]
                while (rr < rk) { segEnd[rr] = sl; rr++ }
            }
            val sx = start % w
            val sy = start / w
            visited[start] = true
            val nb = walk(sx, sy, -1f, bufB)
            val nf = walk(sx, sy, 1f, bufF)
            for (i in nb - 1 downTo 0) seqD[sl++] = bufB[i]
            seqD[sl++] = start
            for (i in 0 until nf) seqD[sl++] = bufF[i]
        }
        while (rr < parts.size) { segEnd[rr] = sl; rr++ }
        // Susun: untuk tiap bagian (urutan acak) kontur tipisnya, lalu goresan arsirannya
        var total = sl
        for (pt in parts) total += pt.size
        val res = IntArray(total)
        var pos = 0
        var prev = 0
        for (r in parts.indices) {
            System.arraycopy(parts[r], 0, res, pos, parts[r].size); pos += parts[r].size
            val e = segEnd[r]
            System.arraycopy(seqD, prev, res, pos, e - prev); pos += e - prev
            prev = e
        }
        return res
    }

    /** Menelusuri garis: urutan piksel mengikuti arah goresan (DFS lurus-dulu). */
    private fun traceStrokes(mask: BooleanArray, w: Int, h: Int, order: IntArray, minRun: Int = 15): IntArray {
        val n = w * h
        var ink = 0
        for (b in mask) if (b) ink++
        val seq = IntArray(ink)
        var sl = 0
        val visited = BooleanArray(n)
        val stackP = IntArray(8 * ink + 16)
        val stackD = IntArray(8 * ink + 16)
        val dxs = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)
        val dys = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
        val cand = IntArray(8)
        val score = IntArray(8)
        for (start in order) {
            if (!mask[start] || visited[start]) continue
            val compStart = sl
            var sp = 0
            stackP[0] = start; stackD[0] = start; sp = 1
            while (sp > 0) {
                sp--
                val p = stackP[sp]
                val par = stackD[sp]
                if (visited[p]) continue
                visited[p] = true
                seq[sl++] = p
                val x = p % w
                val y = p / w
                val ddx = x - par % w
                val ddy = y - par / w
                var c = 0
                for (k in 0 until 8) {
                    val nx = x + dxs[k]
                    val ny = y + dys[k]
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                    val q = ny * w + nx
                    if (!mask[q] || visited[q]) continue
                    val sc = dxs[k] * ddx + dys[k] * ddy
                    var i = c
                    while (i > 0 && score[i - 1] > sc) { score[i] = score[i - 1]; cand[i] = cand[i - 1]; i-- }
                    score[i] = sc; cand[i] = q; c++
                }
                for (i in 0 until c) { stackP[sp] = cand[i]; stackD[sp] = p; sp++ }
            }
            if (sl - compStart < minRun) sl = compStart   // buang bintik noise
        }
        return seq.copyOf(sl)
    }
}
